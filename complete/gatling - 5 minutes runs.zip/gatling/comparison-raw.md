# Extension Constraint Validator — HTTP Impact (RAW)

![comparison](comparison-raw.png)

## Summary table

| Metric | Extensions OFF (baseline) | Extensions ON (shallow JSONPath) | Extensions ON (deep JSONPath + array wildcard) |
|---|---|---|---|
| Requests (total) | 16500 | 16500 | 16500 |
| Requests (OK) | 16500 | 16500 | 16500 |
| Requests (KO) | 0 | 0 | 0 |
| Sustained RPS | 50 rps | 50 rps | 50 rps |
| Mean latency | 1 ms | 1 ms | 1 ms |
| p50 | 1 ms | 1 ms | 1 ms |
| p95 | 2 ms | 3 ms | 2 ms |
| p99 | 4 ms | 4 ms | 3 ms |
| Max | 265 ms | 267 ms | 281 ms |
| Std dev | 5 ms | 5 ms | 5 ms |

## Deltas vs. baseline (`ext-off`)

| Metric | ext-on-shallow | ext-on-deep |
|---|---|---|
| Mean  | +0.0 ms (+0%) | +0.0 ms (+0%) |
| p95   | +1.0 ms (+50%)  | +0.0 ms (+0%)  |
| p99   | +0.0 ms (+0%)  | -1.0 ms (-25%)  |
| Max   | +2.0 ms (+1%)  | +16.0 ms (+6%)  |

## Reading the result

- **`ext-off` → `ext-on-shallow`** = fixed cost of enabling the `ExtensionsJsonPathRegex` validator on the shopping-cart control path (`$.cartCode`).
- **`ext-on-shallow` → `ext-on-deep`** = additional cost of traversing the shopping cart item list with an array wildcard (`$.items[*].productOffering.tags.catalogCode`).
- 0 KO across all runs confirms the comparison is on the validation-pass path.

## Source reports

- [`ext-off-raw-deep-20260420-140338`](ext-off-raw-deep-20260420-140338/index.html)
- [`ext-on-shallow-raw-deep-20260420-140919`](ext-on-shallow-raw-deep-20260420-140919/index.html)
- [`ext-on-deep-raw-deep-20260420-141500`](ext-on-deep-raw-deep-20260420-141500/index.html)