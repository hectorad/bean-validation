allUsersData = {
    
color: '#FFA900',
name: 'Active Users',
data: [
  [1776714329000,6],[1776714330000,6],[1776714331000,5]
],
tooltip: { yDecimals: 0, ySuffix: '', valueDecimals: 0 }
    , zIndex: 20
    , yAxis: 1
};