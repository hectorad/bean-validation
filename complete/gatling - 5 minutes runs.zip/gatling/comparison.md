# Extended Gatling Comparison

30s warmup, 300s steady-state, 50 rps, deep valid payload only.

![comparison](comparison.png)

| Scenario | Mean (ms) | p50 | p75 | p95 | p99 | Max | RPS | Requests | Error rate | Report |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| Validation OFF / map | 2 | 2 | 2 | 3 | 4 | 376 | 50 | 16,500 | 0.0% | [report](/Users/hectorad/Developer/gs-validating-form-input/complete/target/gatling/formvalidationsimulation-20260416102854786/index.html) |
| Validation OFF / raw | 1 | 1 | 2 | 3 | 4 | 225 | 50 | 16,500 | 0.0% | [report](/Users/hectorad/Developer/gs-validating-form-input/complete/target/gatling/formvalidationsimulation-20260416103435946/index.html) |
| Shallow / map | 2 | 1 | 2 | 3 | 4 | 348 | 50 | 16,500 | 0.0% | [report](/Users/hectorad/Developer/gs-validating-form-input/complete/target/gatling/formvalidationsimulation-20260416104055865/index.html) |
| Shallow / raw | 2 | 1 | 2 | 3 | 4 | 237 | 50 | 16,500 | 0.0% | [report](/Users/hectorad/Developer/gs-validating-form-input/complete/target/gatling/formvalidationsimulation-20260416104636168/index.html) |
| Deep / map | 2 | 1 | 2 | 3 | 4 | 435 | 50 | 16,500 | 0.0% | [report](/Users/hectorad/Developer/gs-validating-form-input/complete/target/gatling/formvalidationsimulation-20260416105240152/index.html) |
| Deep / raw | 2 | 1 | 2 | 3 | 3 | 254 | 50 | 16,500 | 0.0% | [report](/Users/hectorad/Developer/gs-validating-form-input/complete/target/gatling/formvalidationsimulation-20260416105820601/index.html) |

All six runs stayed at 0% errors and converged to the same p95 of 3 ms, so the main performance signal still comes from the JMH microbenchmark rather than end-to-end HTTP latency at this load.