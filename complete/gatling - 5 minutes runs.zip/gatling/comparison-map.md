# Extension Constraint Validator — HTTP Impact (MAP)

![comparison](comparison-map.png)

## Summary table

| Metric | Extensions OFF (baseline) | Extensions ON (shallow JSONPath) | Extensions ON (deep JSONPath + array wildcard) |
|---|---|---|---|
| Requests (total) | 16500 | 16500 | 16500 |
| Requests (OK) | 16500 | 16500 | 16500 |
| Requests (KO) | 0 | 0 | 0 |
| Sustained RPS | 50 rps | 50 rps | 50 rps |
| Mean latency | 1 ms | 1 ms | 1 ms |
| p50 | 1 ms | 1 ms | 1 ms |
| p95 | 2 ms | 2 ms | 2 ms |
| p99 | 3 ms | 3 ms | 3 ms |
| Max | 258 ms | 281 ms | 278 ms |
| Std dev | 5 ms | 5 ms | 5 ms |

## Deltas vs. baseline (`ext-off`)

| Metric | ext-on-shallow | ext-on-deep |
|---|---|---|
| Mean  | +0.0 ms (+0%) | +0.0 ms (+0%) |
| p95   | +0.0 ms (+0%)  | +0.0 ms (+0%)  |
| p99   | +0.0 ms (+0%)  | +0.0 ms (+0%)  |
| Max   | +23.0 ms (+9%)  | +20.0 ms (+8%)  |

## Reading the result

- **`ext-off` → `ext-on-shallow`** = fixed cost of enabling the `ExtensionsJsonPathRegex` validator on the shopping-cart control path (`$.cartCode`).
- **`ext-on-shallow` → `ext-on-deep`** = additional cost of traversing the shopping cart item list with an array wildcard (`$.items[*].productOffering.tags.catalogCode`).
- 0 KO across all runs confirms the comparison is on the validation-pass path.

## Source reports

- [`ext-off-map-deep-20260420-134635`](ext-off-map-deep-20260420-134635/index.html)
- [`ext-on-shallow-map-deep-20260420-135216`](ext-on-shallow-map-deep-20260420-135216/index.html)
- [`ext-on-deep-map-deep-20260420-135757`](ext-on-deep-map-deep-20260420-135757/index.html)