allUsersData = {
    
color: '#FFA900',
name: 'Active Users',
data: [
  [1776714316000,6],[1776714317000,6],[1776714318000,5]
],
tooltip: { yDecimals: 0, ySuffix: '', valueDecimals: 0 }
    , zIndex: 20
    , yAxis: 1
};