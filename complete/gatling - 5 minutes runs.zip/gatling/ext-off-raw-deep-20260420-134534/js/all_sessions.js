allUsersData = {
    
color: '#FFA900',
name: 'Active Users',
data: [
  [1776714343000,6],[1776714344000,6],[1776714345000,5]
],
tooltip: { yDecimals: 0, ySuffix: '', valueDecimals: 0 }
    , zIndex: 20
    , yAxis: 1
};