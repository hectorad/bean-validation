allUsersData = {
    
color: '#FFA900',
name: 'Active Users',
data: [
  [1776714357000,6],[1776714358000,6],[1776714359000,5]
],
tooltip: { yDecimals: 0, ySuffix: '', valueDecimals: 0 }
    , zIndex: 20
    , yAxis: 1
};