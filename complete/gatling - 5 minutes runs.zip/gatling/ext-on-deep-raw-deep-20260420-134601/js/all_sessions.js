allUsersData = {
    
color: '#FFA900',
name: 'Active Users',
data: [
  [1776714371000,6],[1776714372000,6],[1776714373000,5]
],
tooltip: { yDecimals: 0, ySuffix: '', valueDecimals: 0 }
    , zIndex: 20
    , yAxis: 1
};