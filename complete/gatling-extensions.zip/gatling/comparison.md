# Extension Constraint Validator — Performance Impact

![comparison](comparison.png)

## Summary table

| Metric | Extensions OFF (baseline) | Extensions ON (shallow JSONPath) | Extensions ON (deep JSONPath + array wildcard) |
|---|---|---|---|
| Requests (total) | 30000 | 30000 | 30000 |
| Requests (OK) | 30000 | 30000 | 30000 |
| Requests (KO) | 0 | 0 | 0 |
| Sustained RPS | 200 rps | 200 rps | 200 rps |
| Mean latency | 1 ms | 2 ms | 2 ms |
| p50 | 1 ms | 1 ms | 1 ms |
| p95 | 2 ms | 2 ms | 2 ms |
| p99 | 3 ms | 5 ms | 5 ms |
| Max | 409 ms | 388 ms | 423 ms |
| Std dev | 11 ms | 10 ms | 12 ms |

## Deltas vs. baseline (`ext-off`)

| Metric | ext-on-shallow | ext-on-deep |
|---|---|---|
| Mean  | +1.0 ms (+100%) | +1.0 ms (+100%) |
| p95   | +0.0 ms (+0%)  | +0.0 ms (+0%)  |
| p99   | +2.0 ms (+67%)  | +2.0 ms (+67%)  |
| Max   | -21.0 ms (-5%)  | +14.0 ms (+3%)  |

## Reading the result

- **`ext-off` → `ext-on-shallow`** = fixed cost of enabling the `ExtensionsJsonPathRegex` validator (single-level JSONPath).
- **`ext-on-shallow` → `ext-on-deep`** = additional cost of traversing a 5-level nested JSON document with an array wildcard (`$.vendor.contact.codes[*].value`).
- 0 KO across all runs confirms the comparison is on the validation-pass path.

_Source reports_: `target/gatling/ext-off-*`, `target/gatling/ext-on-shallow-*`, `target/gatling/ext-on-deep-*`.